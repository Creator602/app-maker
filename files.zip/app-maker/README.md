# App Maker

App Maker is a CLI tool to generate templates for different types of applications.

## Installation

```bash
npm install -g app-maker
```

## Usage

```bash
app-maker
```

You will be prompted to choose the type of app you want to create (Web, Mobile, or Desktop) and the name of your app. The tool will generate the necessary files and folders for your chosen app type.

## License

MIT