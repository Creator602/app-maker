import React from 'react';
import { Text, View } from 'react-native';

const App = () => {
  return (
    <View>
      <Text>Welcome to your Mobile App</Text>
    </View>
  );
};

export default App;